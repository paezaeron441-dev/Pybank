import { Account, Transaction } from "@/types/bank";
import { format, subDays } from "date-fns";

const generateId = () => Math.random().toString(36).substr(2, 9);

export const mockAccounts: Account[] = [
  {
    id: "acc-001",
    accountNumber: "4521873690",
    holderName: "Alexandra Chen",
    accountType: "Savings",
    balance: 84320.5,
    createdAt: "2023-01-15",
  },
  {
    id: "acc-002",
    accountNumber: "7834512096",
    holderName: "Marcus Thompson",
    accountType: "Checking",
    balance: 12750.0,
    createdAt: "2023-03-22",
  },
  {
    id: "acc-003",
    accountNumber: "2190384756",
    holderName: "Priya Sharma",
    accountType: "Savings",
    balance: 230100.75,
    createdAt: "2022-11-08",
  },
  {
    id: "acc-004",
    accountNumber: "6547839201",
    holderName: "James Okafor",
    accountType: "Checking",
    balance: 5430.2,
    createdAt: "2024-02-14",
  },
  {
    id: "acc-005",
    accountNumber: "9823761540",
    holderName: "Sofia Reyes",
    accountType: "Savings",
    balance: 67890.0,
    createdAt: "2023-07-30",
  },
  {
    id: "acc-006",
    accountNumber: "3412095678",
    holderName: "David Kim",
    accountType: "Checking",
    balance: 31245.6,
    createdAt: "2023-09-11",
  },
];

const generateTransactions = (accountId: string, initialBalance: number): Transaction[] => {
  const transactions: Transaction[] = [];
  let running = initialBalance;
  const types: Array<"deposit" | "withdrawal"> = ["deposit", "withdrawal", "deposit", "deposit", "withdrawal", "deposit", "withdrawal", "deposit"];
  
  for (let i = 9; i >= 0; i--) {
    const isDeposit = types[i % types.length] === "deposit";
    const amount = parseFloat((Math.random() * 5000 + 100).toFixed(2));
    if (!isDeposit) running += amount;
    const balance = isDeposit ? running + amount : running;
    transactions.push({
      id: generateId(),
      accountId,
      type: isDeposit ? "deposit" : "withdrawal",
      amount,
      runningBalance: isDeposit ? running + amount : running,
      date: format(subDays(new Date(), i), "yyyy-MM-dd HH:mm:ss"),
      note: isDeposit ? "Direct deposit" : "Bill payment",
    });
    if (isDeposit) running += amount;
    else running -= amount;
  }
  return transactions.reverse();
};

export const mockTransactions: Record<string, Transaction[]> = {
  "acc-001": generateTransactions("acc-001", 84320.5),
  "acc-002": generateTransactions("acc-002", 12750.0),
  "acc-003": generateTransactions("acc-003", 230100.75),
  "acc-004": generateTransactions("acc-004", 5430.2),
  "acc-005": generateTransactions("acc-005", 67890.0),
  "acc-006": generateTransactions("acc-006", 31245.6),
};
