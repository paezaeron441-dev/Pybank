import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { Account, Transaction, UserRole, Notification } from "@/types/bank";
import { mockAccounts, mockTransactions } from "@/data/mockData";
import { format } from "date-fns";

interface BankContextType {
  accounts: Account[];
  transactions: Record<string, Transaction[]>;
  selectedAccount: Account | null;
  userRole: UserRole;
  notifications: Notification[];
  setUserRole: (role: UserRole) => void;
  selectAccount: (account: Account) => void;
  deposit: (accountId: string, amount: number, note?: string) => void;
  withdraw: (accountId: string, amount: number, note?: string) => boolean;
  transfer: (fromAccountId: string, toAccountId: string, amount: number, note?: string) => boolean;
  createAccount: (holderName: string, accountType: "Savings" | "Checking", initialDeposit: number) => void;
  deleteAccount: (accountId: string) => void;
  markNotificationsRead: () => void;
  todayDeposits: number;
  todayWithdrawals: number;
}

const BankContext = createContext<BankContextType | undefined>(undefined);

export const BankProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [accounts, setAccounts] = useState<Account[]>(mockAccounts);
  const [transactions, setTransactions] = useState<Record<string, Transaction[]>>(mockTransactions);
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(mockAccounts[0]);
  const [userRole, setUserRole] = useState<UserRole>("admin");
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const addNotification = useCallback((message: string, type: "success" | "error" | "info") => {
    const notif: Notification = {
      id: Math.random().toString(36).substr(2, 9),
      message,
      type,
      timestamp: new Date().toISOString(),
      read: false,
    };
    setNotifications((prev) => [notif, ...prev.slice(0, 9)]);
  }, []);

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const selectAccount = useCallback((account: Account) => {
    setSelectedAccount(account);
  }, []);

  const deposit = useCallback((accountId: string, amount: number, note?: string) => {
    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === accountId ? { ...acc, balance: acc.balance + amount } : acc
      )
    );
    setSelectedAccount((prev) =>
      prev?.id === accountId ? { ...prev, balance: prev.balance + amount } : prev
    );

    setTransactions((prev) => {
      const accTransactions = prev[accountId] || [];
      const lastBalance = accTransactions.length > 0
        ? accTransactions[accTransactions.length - 1].runningBalance
        : amount;
      const newTransaction: Transaction = {
        id: generateId(),
        accountId,
        type: "deposit",
        amount,
        note: note || "Deposit",
        runningBalance: lastBalance + amount,
        date: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
      };
      return { ...prev, [accountId]: [...accTransactions, newTransaction] };
    });

    addNotification(`Deposit of $${amount.toFixed(2)} successful`, "success");
  }, [addNotification]);

  const withdraw = useCallback((accountId: string, amount: number, note?: string): boolean => {
    const account = accounts.find((a) => a.id === accountId);
    if (!account || account.balance < amount) return false;

    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === accountId ? { ...acc, balance: acc.balance - amount } : acc
      )
    );
    setSelectedAccount((prev) =>
      prev?.id === accountId ? { ...prev, balance: prev.balance - amount } : prev
    );

    setTransactions((prev) => {
      const accTransactions = prev[accountId] || [];
      const lastBalance = accTransactions.length > 0
        ? accTransactions[accTransactions.length - 1].runningBalance
        : 0;
      const newTransaction: Transaction = {
        id: generateId(),
        accountId,
        type: "withdrawal",
        amount,
        note: note || "Withdrawal",
        runningBalance: lastBalance - amount,
        date: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
      };
      return { ...prev, [accountId]: [...accTransactions, newTransaction] };
    });

    addNotification(`Withdrawal of $${amount.toFixed(2)} successful`, "success");
    return true;
  }, [accounts, addNotification]);

  const transfer = useCallback((fromAccountId: string, toAccountId: string, amount: number, note?: string): boolean => {
    const fromAccount = accounts.find((a) => a.id === fromAccountId);
    const toAccount = accounts.find((a) => a.id === toAccountId);
    if (!fromAccount || !toAccount || fromAccount.balance < amount) return false;

    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === fromAccountId) return { ...acc, balance: acc.balance - amount };
        if (acc.id === toAccountId) return { ...acc, balance: acc.balance + amount };
        return acc;
      })
    );
    setSelectedAccount((prev) =>
      prev?.id === fromAccountId ? { ...prev, balance: prev.balance - amount } : prev
    );

    setTransactions((prev) => {
      const fromTxns = prev[fromAccountId] || [];
      const toTxns = prev[toAccountId] || [];
      const fromLast = fromTxns.length > 0 ? fromTxns[fromTxns.length - 1].runningBalance : 0;
      const toLast = toTxns.length > 0 ? toTxns[toTxns.length - 1].runningBalance : 0;

      return {
        ...prev,
        [fromAccountId]: [...fromTxns, {
          id: generateId(), accountId: fromAccountId, type: "transfer_out",
          amount, note: note || `Transfer to ${toAccount.accountNumber}`,
          runningBalance: fromLast - amount, date: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
          toAccountId, toAccountNumber: toAccount.accountNumber,
        }],
        [toAccountId]: [...toTxns, {
          id: generateId(), accountId: toAccountId, type: "transfer_in",
          amount, note: note || `Transfer from ${fromAccount.accountNumber}`,
          runningBalance: toLast + amount, date: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
        }],
      };
    });

    addNotification(`Transfer of $${amount.toFixed(2)} to ${toAccount.holderName} successful`, "success");
    return true;
  }, [accounts, addNotification]);

  const createAccount = useCallback((holderName: string, accountType: "Savings" | "Checking", initialDeposit: number) => {
    const newAccount: Account = {
      id: `acc-${generateId()}`,
      accountNumber: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
      holderName,
      accountType,
      balance: initialDeposit,
      createdAt: format(new Date(), "yyyy-MM-dd"),
    };
    setAccounts((prev) => [...prev, newAccount]);
    setTransactions((prev) => ({
      ...prev,
      [newAccount.id]: [{
        id: generateId(), accountId: newAccount.id, type: "deposit",
        amount: initialDeposit, note: "Initial deposit",
        runningBalance: initialDeposit, date: format(new Date(), "yyyy-MM-dd HH:mm:ss"),
      }],
    }));
    setSelectedAccount(newAccount);
    addNotification(`Account created for ${holderName}`, "success");
  }, [addNotification]);

  const deleteAccount = useCallback((accountId: string) => {
    const account = accounts.find((a) => a.id === accountId);
    setAccounts((prev) => prev.filter((a) => a.id !== accountId));
    setTransactions((prev) => {
      const newTxns = { ...prev };
      delete newTxns[accountId];
      return newTxns;
    });
    setSelectedAccount((prev) => {
      if (prev?.id === accountId) {
        const remaining = accounts.filter((a) => a.id !== accountId);
        return remaining[0] || null;
      }
      return prev;
    });
    addNotification(`Account for ${account?.holderName} deleted`, "info");
  }, [accounts, addNotification]);

  const markNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const todayDeposits = Object.values(transactions)
    .flat()
    .filter((t) => t.type === "deposit" && t.date.startsWith(format(new Date(), "yyyy-MM-dd")))
    .reduce((sum, t) => sum + t.amount, 0);

  const todayWithdrawals = Object.values(transactions)
    .flat()
    .filter((t) => t.type === "withdrawal" && t.date.startsWith(format(new Date(), "yyyy-MM-dd")))
    .reduce((sum, t) => sum + t.amount, 0);

  return (
    <BankContext.Provider value={{
      accounts, transactions, selectedAccount, userRole, notifications,
      setUserRole, selectAccount, deposit, withdraw, transfer,
      createAccount, deleteAccount, markNotificationsRead,
      todayDeposits, todayWithdrawals,
    }}>
      {children}
    </BankContext.Provider>
  );
};

export const useBank = () => {
  const ctx = useContext(BankContext);
  if (!ctx) throw new Error("useBank must be used within BankProvider");
  return ctx;
};
