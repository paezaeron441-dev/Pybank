import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BankProvider } from "@/context/BankContext";
import TopNav from "@/components/bank/TopNav";
import AccountSidebar from "@/components/bank/AccountSidebar";
import HeroCard from "@/components/bank/HeroCard";
import QuickActions from "@/components/bank/QuickActions";
import TransactionTable from "@/components/bank/TransactionTable";
import Drawer from "@/components/bank/Drawer";
import FooterStats from "@/components/bank/FooterStats";
import { Toaster } from "sonner";
import { useBank } from "@/context/BankContext";

type DrawerType = "deposit" | "withdraw" | "transfer" | "new-account";

const DashboardContent: React.FC = () => {
  const { selectedAccount } = useBank();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerType, setDrawerType] = useState<DrawerType>("deposit");
  const [isPulsing, setIsPulsing] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const openDrawer = (type: DrawerType) => {
    setDrawerType(type);
    setDrawerOpen(true);
  };

  const handleBalanceInquiry = () => {
    setIsPulsing(true);
    setTimeout(() => setIsPulsing(false), 1000);
  };

  return (
    <div
      className="flex flex-col min-h-screen"
      style={{
        background: "#0D1B2A",
        backgroundImage: `
          radial-gradient(ellipse at 20% 0%, rgba(0,201,167,0.04) 0%, transparent 50%),
          radial-gradient(ellipse at 80% 100%, rgba(100,149,237,0.04) 0%, transparent 50%)
        `,
      }}
    >
      {/* Sticky Top Nav */}
      <TopNav />

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden" style={{ height: "calc(100vh - 112px)" }}>
        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={mounted ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="flex-shrink-0 overflow-hidden"
          style={{
            width: "260px",
            borderRight: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <AccountSidebar onNewAccount={() => openDrawer("new-account")} />
        </motion.div>

        {/* Main content */}
        <div className="flex-1 overflow-y-auto px-8 py-7 space-y-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedAccount?.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
            >
              {/* Hero Card */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={mounted ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.4, delay: 0.1 }}
              >
                <HeroCard onBalanceInquiry={handleBalanceInquiry} isPulsing={isPulsing} />
              </motion.div>
            </motion.div>
          </AnimatePresence>

          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={mounted ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <QuickActions
              onDeposit={() => openDrawer("deposit")}
              onWithdraw={() => openDrawer("withdraw")}
              onTransfer={() => openDrawer("transfer")}
              onBalanceInquiry={handleBalanceInquiry}
            />
          </motion.div>

          {/* Transaction Table */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={mounted ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.4, delay: 0.3 }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedAccount?.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <TransactionTable />
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <FooterStats />

      {/* Drawer */}
      <Drawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        type={drawerType}
      />

      {/* Toast notifications */}
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: "#1C2E42",
            border: "1px solid rgba(255,255,255,0.1)",
            color: "#E8F0F7",
            fontFamily: "Manrope, sans-serif",
            fontSize: "13px",
          },
        }}
      />
    </div>
  );
};

function Home() {
  return (
    <BankProvider>
      <DashboardContent />
    </BankProvider>
  );
}

export default Home;
