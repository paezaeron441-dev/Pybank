import React from "react";
import { ArrowDownCircle, ArrowUpCircle, ArrowLeftRight, Search } from "lucide-react";
import { useBank } from "@/context/BankContext";
import { UserRole } from "@/types/bank";

interface QuickActionsProps {
  onDeposit: () => void;
  onWithdraw: () => void;
  onTransfer: () => void;
  onBalanceInquiry: () => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({
  onDeposit,
  onWithdraw,
  onTransfer,
  onBalanceInquiry,
}) => {
  const { userRole, selectedAccount } = useBank();

  const actions = [
    {
      id: "deposit",
      label: "Deposit",
      icon: ArrowDownCircle,
      color: "#00C9A7",
      bg: "rgba(0,201,167,0.08)",
      border: "rgba(0,201,167,0.2)",
      hoverBg: "rgba(0,201,167,0.15)",
      onClick: onDeposit,
      allowedRoles: ["admin", "staff"] as UserRole[],
    },
    {
      id: "withdraw",
      label: "Withdraw",
      icon: ArrowUpCircle,
      color: "#FF5C5C",
      bg: "rgba(255,92,92,0.08)",
      border: "rgba(255,92,92,0.2)",
      hoverBg: "rgba(255,92,92,0.15)",
      onClick: onWithdraw,
      allowedRoles: ["admin", "staff"] as UserRole[],
    },
    {
      id: "transfer",
      label: "Transfer",
      icon: ArrowLeftRight,
      color: "#6495ED",
      bg: "rgba(100,149,237,0.08)",
      border: "rgba(100,149,237,0.2)",
      hoverBg: "rgba(100,149,237,0.15)",
      onClick: onTransfer,
      allowedRoles: ["admin", "staff"] as UserRole[],
    },
    {
      id: "inquiry",
      label: "Balance Inquiry",
      icon: Search,
      color: "#A78BFA",
      bg: "rgba(167,139,250,0.08)",
      border: "rgba(167,139,250,0.2)",
      hoverBg: "rgba(167,139,250,0.15)",
      onClick: onBalanceInquiry,
      allowedRoles: ["admin", "staff", "customer"] as UserRole[],
    },
  ];

  const isAllowed = (roles: UserRole[]) => roles.includes(userRole);

  return (
    <div className="grid grid-cols-4 gap-3">
      {actions.map((action) => {
        const allowed = isAllowed(action.allowedRoles);
        const Icon = action.icon;

        return (
          <button
            key={action.id}
            onClick={allowed && selectedAccount ? action.onClick : undefined}
            disabled={!allowed || !selectedAccount}
            className="group relative flex flex-col items-center gap-3 p-4 rounded-2xl transition-all duration-200"
            style={{
              background: allowed ? action.bg : "rgba(255,255,255,0.02)",
              border: `1px solid ${allowed ? action.border : "rgba(255,255,255,0.05)"}`,
              opacity: allowed && selectedAccount ? 1 : 0.35,
              cursor: allowed && selectedAccount ? "pointer" : "not-allowed",
            }}
            onMouseEnter={(e) => {
              if (allowed && selectedAccount) {
                (e.currentTarget as HTMLButtonElement).style.background = action.hoverBg;
                (e.currentTarget as HTMLButtonElement).style.transform = "translateY(-4px)";
                (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 8px 24px ${action.color}22`;
              }
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = allowed ? action.bg : "rgba(255,255,255,0.02)";
              (e.currentTarget as HTMLButtonElement).style.transform = "translateY(0)";
              (e.currentTarget as HTMLButtonElement).style.boxShadow = "none";
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: allowed ? `${action.color}18` : "rgba(255,255,255,0.04)",
                border: `1px solid ${allowed ? `${action.color}30` : "rgba(255,255,255,0.06)"}`,
              }}
            >
              <Icon
                size={18}
                style={{ color: allowed ? action.color : "#7A9BB5" }}
              />
            </div>
            <span
              className="text-xs font-medium text-center leading-tight"
              style={{
                color: allowed ? "#E8F0F7" : "#7A9BB5",
                fontFamily: "Manrope, sans-serif",
              }}
            >
              {action.label}
            </span>
            {!allowed && (
              <span
                className="absolute top-2 right-2 text-[8px] px-1.5 py-0.5 rounded-full"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  color: "#7A9BB5",
                  fontFamily: "Manrope, sans-serif",
                }}
              >
                Restricted
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};

export default QuickActions;
