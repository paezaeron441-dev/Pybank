import React, { useState, useEffect, useRef } from "react";
import { Bell, ChevronDown, Shield, User, Users } from "lucide-react";
import { useBank } from "@/context/BankContext";
import { UserRole } from "@/types/bank";
import { format } from "date-fns";

const TopNav: React.FC = () => {
  const { userRole, setUserRole, notifications, markNotificationsRead } = useBank();
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const roleRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (roleRef.current && !roleRef.current.contains(e.target as Node)) setShowRoleMenu(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  const roleConfig: Record<UserRole, { label: string; icon: React.ReactNode; color: string }> = {
    admin: { label: "Admin", icon: <Shield size={12} />, color: "text-[#00C9A7] border-[#00C9A7]/30 bg-[#00C9A7]/10" },
    staff: { label: "Staff", icon: <Users size={12} />, color: "text-blue-400 border-blue-400/30 bg-blue-400/10" },
    customer: { label: "Customer", icon: <User size={12} />, color: "text-purple-400 border-purple-400/30 bg-purple-400/10" },
  };

  return (
    <header
      className="sticky top-0 z-50 h-16 flex items-center justify-between px-6"
      style={{
        background: "rgba(13,27,42,0.85)",
        backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(0,201,167,0.12)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.4)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: "linear-gradient(135deg, #00C9A7, #007D6A)" }}
        >
          <span className="text-white font-bold text-sm" style={{ fontFamily: "Syne, sans-serif" }}>N</span>
        </div>
        <div>
          <h1
            className="text-[#E8F0F7] font-extrabold text-lg leading-none tracking-tight"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            PAEZBANK
          </h1>
          <p className="text-[#7A9BB5] text-[10px] leading-none mt-0.5" style={{ fontFamily: "Manrope, sans-serif" }}>
            Management System
          </p>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-3">
        {/* Role Switcher */}
        <div className="relative" ref={roleRef}>
          <button
            onClick={() => setShowRoleMenu(!showRoleMenu)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition-all duration-200 hover:scale-105 ${roleConfig[userRole].color}`}
            style={{ fontFamily: "Manrope, sans-serif" }}
          >
            {roleConfig[userRole].icon}
            {roleConfig[userRole].label}
            <ChevronDown size={10} className={`transition-transform ${showRoleMenu ? "rotate-180" : ""}`} />
          </button>
          {showRoleMenu && (
            <div
              className="absolute right-0 top-full mt-2 w-36 rounded-xl overflow-hidden shadow-xl"
              style={{ background: "#1C2E42", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              {(["admin", "staff", "customer"] as UserRole[]).map((role) => (
                <button
                  key={role}
                  onClick={() => { setUserRole(role); setShowRoleMenu(false); }}
                  className={`w-full flex items-center gap-2 px-4 py-2.5 text-xs transition-colors hover:bg-white/5 ${
                    userRole === role ? "text-[#00C9A7]" : "text-[#E8F0F7]"
                  }`}
                  style={{ fontFamily: "Manrope, sans-serif" }}
                >
                  {roleConfig[role].icon}
                  {roleConfig[role].label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notification Bell */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => { setShowNotifications(!showNotifications); if (!showNotifications) markNotificationsRead(); }}
            className="relative w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 hover:bg-white/5"
            style={{ border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <Bell size={16} className="text-[#7A9BB5]" />
            {unreadCount > 0 && (
              <span
                className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-[9px] font-bold flex items-center justify-center text-white"
                style={{ background: "#FF5C5C" }}
              >
                {unreadCount}
              </span>
            )}
          </button>
          {showNotifications && (
            <div
              className="absolute right-0 top-full mt-2 w-80 rounded-xl overflow-hidden shadow-xl"
              style={{ background: "#1C2E42", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                <p className="text-[#E8F0F7] text-sm font-semibold" style={{ fontFamily: "Manrope, sans-serif" }}>
                  Notifications
                </p>
              </div>
              <div className="max-h-64 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="px-4 py-8 text-center text-[#7A9BB5] text-sm" style={{ fontFamily: "Manrope, sans-serif" }}>
                    No notifications
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className="px-4 py-3 border-b hover:bg-white/5 transition-colors"
                      style={{ borderColor: "rgba(255,255,255,0.04)" }}
                    >
                      <div className="flex items-start gap-2">
                        <div
                          className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                          style={{
                            background: notif.type === "success" ? "#00C9A7" : notif.type === "error" ? "#FF5C5C" : "#7A9BB5",
                          }}
                        />
                        <div>
                          <p className="text-[#E8F0F7] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>
                            {notif.message}
                          </p>
                          <p className="text-[#7A9BB5] text-[10px] mt-0.5" style={{ fontFamily: "Manrope, sans-serif" }}>
                            {format(new Date(notif.timestamp), "HH:mm")}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default TopNav;
