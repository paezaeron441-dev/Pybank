import React from "react";
import { useBank } from "@/context/BankContext";
import { BarChart3, TrendingDown, TrendingUp, Users } from "lucide-react";

const FooterStats: React.FC = () => {
  const { accounts, todayDeposits, todayWithdrawals } = useBank();

  const totalBalance = accounts.reduce((sum, a) => sum + a.balance, 0);

  const formatAmount = (val: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact", maximumFractionDigits: 1 }).format(val);

  const stats = [
    {
      label: "Total Accounts",
      value: accounts.length.toString(),
      icon: <Users size={13} />,
      color: "#7A9BB5",
    },
    {
      label: "Total AUM",
      value: formatAmount(totalBalance),
      icon: <BarChart3 size={13} />,
      color: "#00C9A7",
    },
    {
      label: "Deposits Today",
      value: formatAmount(todayDeposits),
      icon: <TrendingUp size={13} />,
      color: "#00C9A7",
    },
    {
      label: "Withdrawals Today",
      value: formatAmount(todayWithdrawals),
      icon: <TrendingDown size={13} />,
      color: "#FF5C5C",
    },
  ];

  return (
    <footer
      className="flex items-center justify-between px-6 h-12"
      style={{
        background: "rgba(13,27,42,0.9)",
        borderTop: "1px solid rgba(255,255,255,0.06)",
        backdropFilter: "blur(10px)",
      }}
    >
      <div className="flex items-center gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="flex items-center gap-2">
            <div
              className="flex items-center gap-1.5 px-3 py-1 rounded-full"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}
            >
              <span style={{ color: stat.color }}>{stat.icon}</span>
              <span
                className="text-[10px] uppercase tracking-widest"
                style={{ color: "#7A9BB5", fontFamily: "Manrope, sans-serif" }}
              >
                {stat.label}:
              </span>
              <span
                className="text-[11px] font-bold"
                style={{ color: stat.color, fontFamily: "JetBrains Mono, monospace" }}
              >
                {stat.value}
              </span>
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2">
        <div
          className="w-1.5 h-1.5 rounded-full"
          style={{ background: "#00C9A7", boxShadow: "0 0 6px #00C9A7" }}
        />
        <span
          className="text-[10px] uppercase tracking-widest"
          style={{ color: "#7A9BB5", fontFamily: "Manrope, sans-serif" }}
        >
          System Online
        </span>
      </div>
    </footer>
  );
};

export default FooterStats;
