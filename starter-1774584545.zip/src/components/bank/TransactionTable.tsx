import React, { useState, useMemo } from "react";
import {
  ArrowDownCircle,
  ArrowUpCircle,
  ArrowLeftRight,
  Search,
  Filter,
  ChevronDown,
} from "lucide-react";
import { useBank } from "@/context/BankContext";
import { Transaction } from "@/types/bank";
import { format } from "date-fns";

const TransactionTable: React.FC = () => {
  const { selectedAccount, transactions } = useBank();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [showFilter, setShowFilter] = useState(false);

  const accountTransactions = selectedAccount ? transactions[selectedAccount.id] || [] : [];

  const filtered = useMemo(() => {
    return accountTransactions
      .filter((t) => {
        const matchesSearch =
          search === "" ||
          t.note?.toLowerCase().includes(search.toLowerCase()) ||
          t.amount.toString().includes(search) ||
          t.date.includes(search);
        const matchesType = typeFilter === "all" || t.type === typeFilter;
        return matchesSearch && matchesType;
      })
      .slice()
      .reverse();
  }, [accountTransactions, search, typeFilter]);

  const formatAmount = (amount: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(amount);

  const typeConfig: Record<string, { label: string; icon: React.ReactNode; color: string; prefix: string }> = {
    deposit: { label: "Deposit", icon: <ArrowDownCircle size={12} />, color: "#00C9A7", prefix: "+" },
    withdrawal: { label: "Withdrawal", icon: <ArrowUpCircle size={12} />, color: "#FF5C5C", prefix: "-" },
    transfer_in: { label: "Transfer In", icon: <ArrowLeftRight size={12} />, color: "#00C9A7", prefix: "+" },
    transfer_out: { label: "Transfer Out", icon: <ArrowLeftRight size={12} />, color: "#FF5C5C", prefix: "-" },
  };

  const filterOptions = [
    { value: "all", label: "All Types" },
    { value: "deposit", label: "Deposits" },
    { value: "withdrawal", label: "Withdrawals" },
    { value: "transfer_in", label: "Transfer In" },
    { value: "transfer_out", label: "Transfer Out" },
  ];

  return (
    <div
      className="flex flex-col rounded-2xl overflow-hidden"
      style={{
        background: "#1C2E42",
        border: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <h3
          className="text-[#E8F0F7] font-bold text-sm uppercase tracking-widest"
          style={{ fontFamily: "Syne, sans-serif" }}
        >
          Transaction History
        </h3>
        <span
          className="text-[#7A9BB5] text-xs"
          style={{ fontFamily: "Manrope, sans-serif" }}
        >
          {filtered.length} records
        </span>
      </div>

      {/* Filter bar */}
      <div
        className="flex items-center gap-3 px-5 py-3"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
      >
        <div className="relative flex-1">
          <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#7A9BB5]" />
          <input
            type="text"
            placeholder="Search transactions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 text-xs text-[#E8F0F7] placeholder-[#7A9BB5] rounded-lg outline-none focus:ring-1 focus:ring-[#00C9A7]/40 transition-all"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.07)",
              fontFamily: "Manrope, sans-serif",
            }}
          />
        </div>
        <div className="relative">
          <button
            onClick={() => setShowFilter(!showFilter)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs transition-all hover:bg-white/5"
            style={{
              background: typeFilter !== "all" ? "rgba(0,201,167,0.1)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${typeFilter !== "all" ? "rgba(0,201,167,0.3)" : "rgba(255,255,255,0.07)"}`,
              color: typeFilter !== "all" ? "#00C9A7" : "#7A9BB5",
              fontFamily: "Manrope, sans-serif",
            }}
          >
            <Filter size={11} />
            {filterOptions.find((o) => o.value === typeFilter)?.label}
            <ChevronDown size={10} className={`transition-transform ${showFilter ? "rotate-180" : ""}`} />
          </button>
          {showFilter && (
            <div
              className="absolute right-0 top-full mt-1 w-36 rounded-xl overflow-hidden shadow-xl z-20"
              style={{ background: "#0D1B2A", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              {filterOptions.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => { setTypeFilter(opt.value); setShowFilter(false); }}
                  className="w-full text-left px-3 py-2 text-xs hover:bg-white/5 transition-colors"
                  style={{
                    color: typeFilter === opt.value ? "#00C9A7" : "#E8F0F7",
                    fontFamily: "Manrope, sans-serif",
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-auto max-h-72">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center mb-3"
              style={{ background: "rgba(255,255,255,0.04)" }}
            >
              <Search size={16} className="text-[#7A9BB5]" />
            </div>
            <p className="text-[#7A9BB5] text-sm" style={{ fontFamily: "Manrope, sans-serif" }}>
              No transactions found
            </p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr style={{ background: "rgba(0,0,0,0.2)" }}>
                {["Date & Time", "Type", "Note", "Amount", "Balance"].map((h) => (
                  <th
                    key={h}
                    className="px-5 py-3 text-left text-[10px] uppercase tracking-widest"
                    style={{ color: "#7A9BB5", fontFamily: "Manrope, sans-serif" }}
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((txn, i) => {
                const config = typeConfig[txn.type];
                const isCredit = txn.type === "deposit" || txn.type === "transfer_in";
                return (
                  <tr
                    key={txn.id}
                    className="transition-colors hover:bg-white/[0.02]"
                    style={{
                      background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)",
                      borderBottom: "1px solid rgba(255,255,255,0.04)",
                    }}
                  >
                    <td className="px-5 py-3">
                      <span
                        className="text-[11px]"
                        style={{ color: "#7A9BB5", fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {format(new Date(txn.date), "MMM dd, HH:mm")}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium"
                        style={{
                          background: `${config.color}15`,
                          color: config.color,
                          border: `1px solid ${config.color}25`,
                          fontFamily: "Manrope, sans-serif",
                        }}
                      >
                        {config.icon}
                        {config.label}
                      </div>
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className="text-xs text-[#B0C8D8] truncate max-w-[120px] block"
                        style={{ fontFamily: "Manrope, sans-serif" }}
                      >
                        {txn.note || "—"}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className="font-semibold text-xs"
                        style={{
                          color: isCredit ? "#00C9A7" : "#FF5C5C",
                          fontFamily: "JetBrains Mono, monospace",
                        }}
                      >
                        {config.prefix}{formatAmount(txn.amount)}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className="text-xs"
                        style={{ color: "#7A9BB5", fontFamily: "JetBrains Mono, monospace" }}
                      >
                        {formatAmount(txn.runningBalance)}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default TransactionTable;
