import React, { useState } from "react";
import { Search, ChevronRight, Plus, Trash2, Wallet, CreditCard } from "lucide-react";
import { useBank } from "@/context/BankContext";
import { Account } from "@/types/bank";

interface AccountSidebarProps {
  onNewAccount: () => void;
}

const AccountSidebar: React.FC<AccountSidebarProps> = ({ onNewAccount }) => {
  const { accounts, selectedAccount, selectAccount, deleteAccount, userRole } = useBank();
  const [search, setSearch] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filtered = accounts.filter(
    (a) =>
      a.holderName.toLowerCase().includes(search.toLowerCase()) ||
      a.accountNumber.includes(search)
  );

  const maskNumber = (num: string) => `•••• ${num.slice(-4)}`;

  const formatBalance = (balance: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 0 }).format(balance);

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (deleteConfirm === id) {
      deleteAccount(id);
      setDeleteConfirm(null);
    } else {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000);
    }
  };

  return (
    <aside
      className="flex flex-col h-full"
      style={{ background: "#0D1B2A" }}
    >
      {/* Header */}
      <div className="px-4 pt-5 pb-4">
        <div className="flex items-center justify-between mb-4">
          <h2
            className="text-[#E8F0F7] font-bold text-sm uppercase tracking-widest"
            style={{ fontFamily: "Syne, sans-serif" }}
          >
            Accounts
          </h2>
          {userRole === "admin" && (
            <button
              onClick={onNewAccount}
              className="w-7 h-7 rounded-lg flex items-center justify-center transition-all duration-200 hover:scale-110"
              style={{ background: "rgba(0,201,167,0.15)", border: "1px solid rgba(0,201,167,0.3)" }}
              title="Create new account"
            >
              <Plus size={13} className="text-[#00C9A7]" />
            </button>
          )}
        </div>

        {/* Search */}
        <div className="relative">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#7A9BB5]" />
          <input
            type="text"
            placeholder="Search accounts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-2 text-xs text-[#E8F0F7] placeholder-[#7A9BB5] rounded-lg outline-none transition-all duration-200 focus:ring-1 focus:ring-[#00C9A7]/40"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              fontFamily: "Manrope, sans-serif",
            }}
          />
        </div>
      </div>

      {/* Account count */}
      <div className="px-4 mb-2">
        <p className="text-[#7A9BB5] text-[10px] uppercase tracking-widest" style={{ fontFamily: "Manrope, sans-serif" }}>
          {filtered.length} of {accounts.length} accounts
        </p>
      </div>

      {/* Account list */}
      <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-1.5 scrollbar-thin">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center mb-3"
              style={{ background: "rgba(255,255,255,0.04)" }}
            >
              <Search size={16} className="text-[#7A9BB5]" />
            </div>
            <p className="text-[#7A9BB5] text-xs text-center" style={{ fontFamily: "Manrope, sans-serif" }}>
              No accounts found
            </p>
          </div>
        ) : (
          filtered.map((account) => {
            const isSelected = selectedAccount?.id === account.id;
            const isDeleteConfirm = deleteConfirm === account.id;

            return (
              <div
                key={account.id}
                onClick={() => selectAccount(account)}
                className="group relative rounded-xl p-3 cursor-pointer transition-all duration-200"
                style={{
                  background: isSelected
                    ? "linear-gradient(135deg, rgba(0,201,167,0.12), rgba(0,201,167,0.06))"
                    : "rgba(255,255,255,0.02)",
                  border: isSelected
                    ? "1px solid rgba(0,201,167,0.25)"
                    : "1px solid rgba(255,255,255,0.04)",
                  transform: isSelected ? "translateX(2px)" : "none",
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{
                      background: isSelected
                        ? "rgba(0,201,167,0.15)"
                        : "rgba(255,255,255,0.05)",
                    }}
                  >
                    {account.accountType === "Savings" ? (
                      <Wallet size={14} className={isSelected ? "text-[#00C9A7]" : "text-[#7A9BB5]"} />
                    ) : (
                      <CreditCard size={14} className={isSelected ? "text-[#00C9A7]" : "text-[#7A9BB5]"} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className="text-xs font-semibold truncate"
                      style={{
                        color: isSelected ? "#E8F0F7" : "#B0C8D8",
                        fontFamily: "Manrope, sans-serif",
                      }}
                    >
                      {account.holderName}
                    </p>
                    <p
                      className="text-[10px] mt-0.5"
                      style={{
                        color: "#7A9BB5",
                        fontFamily: "JetBrains Mono, monospace",
                        letterSpacing: "0.05em",
                      }}
                    >
                      {maskNumber(account.accountNumber)}
                    </p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span
                        className="text-xs font-semibold"
                        style={{
                          color: isSelected ? "#00C9A7" : "#7A9BB5",
                          fontFamily: "JetBrains Mono, monospace",
                        }}
                      >
                        {formatBalance(account.balance)}
                      </span>
                      <span
                        className="text-[9px] px-1.5 py-0.5 rounded-full"
                        style={{
                          background: account.accountType === "Savings"
                            ? "rgba(0,201,167,0.1)"
                            : "rgba(100,149,237,0.1)",
                          color: account.accountType === "Savings" ? "#00C9A7" : "#6495ED",
                          fontFamily: "Manrope, sans-serif",
                          border: `1px solid ${account.accountType === "Savings" ? "rgba(0,201,167,0.2)" : "rgba(100,149,237,0.2)"}`,
                        }}
                      >
                        {account.accountType}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    {isSelected && <ChevronRight size={12} className="text-[#00C9A7]" />}
                    {userRole === "admin" && (
                      <button
                        onClick={(e) => handleDelete(account.id, e)}
                        className={`opacity-0 group-hover:opacity-100 w-5 h-5 rounded flex items-center justify-center transition-all duration-200 hover:scale-110 ${
                          isDeleteConfirm ? "opacity-100" : ""
                        }`}
                        style={{
                          background: isDeleteConfirm ? "rgba(255,92,92,0.2)" : "rgba(255,92,92,0.1)",
                          border: `1px solid ${isDeleteConfirm ? "rgba(255,92,92,0.4)" : "rgba(255,92,92,0.2)"}`,
                        }}
                        title={isDeleteConfirm ? "Confirm delete" : "Delete account"}
                      >
                        <Trash2 size={9} className="text-[#FF5C5C]" />
                      </button>
                    )}
                  </div>
                </div>
                {isDeleteConfirm && (
                  <div
                    className="mt-2 px-2 py-1 rounded text-[10px] text-center"
                    style={{
                      background: "rgba(255,92,92,0.1)",
                      color: "#FF5C5C",
                      fontFamily: "Manrope, sans-serif",
                    }}
                  >
                    Click again to confirm delete
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
};

export default AccountSidebar;
