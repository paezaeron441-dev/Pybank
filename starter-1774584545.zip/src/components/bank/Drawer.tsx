import React, { useState } from "react";
import { X, DollarSign, FileText, AlertCircle, CheckCircle } from "lucide-react";
import { useBank } from "@/context/BankContext";

interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  type: "deposit" | "withdraw" | "transfer" | "new-account";
}

const Drawer: React.FC<DrawerProps> = ({ isOpen, onClose, type }) => {
  const { deposit, withdraw, transfer, createAccount, selectedAccount, accounts, userRole } = useBank();
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [toAccountId, setToAccountId] = useState("");
  const [holderName, setHolderName] = useState("");
  const [accountType, setAccountType] = useState<"Savings" | "Checking">("Savings");
  const [initialDeposit, setInitialDeposit] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [step, setStep] = useState<"form" | "confirm">("form");
  const [success, setSuccess] = useState(false);

  const resetForm = () => {
    setAmount("");
    setNote("");
    setToAccountId("");
    setHolderName("");
    setAccountType("Savings");
    setInitialDeposit("");
    setErrors({});
    setStep("form");
    setSuccess(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (type === "deposit" || type === "withdraw") {
      const amt = parseFloat(amount);
      if (!amount || isNaN(amt) || amt <= 0) {
        newErrors.amount = "Please enter a valid amount greater than 0";
      }
      if (type === "withdraw" && selectedAccount && amt > selectedAccount.balance) {
        newErrors.amount = `Insufficient funds. Available: $${selectedAccount.balance.toFixed(2)}`;
      }
    }

    if (type === "transfer") {
      const amt = parseFloat(amount);
      if (!amount || isNaN(amt) || amt <= 0) newErrors.amount = "Please enter a valid amount";
      if (!toAccountId) newErrors.toAccount = "Please select a destination account";
      if (selectedAccount && amt > selectedAccount.balance) {
        newErrors.amount = `Insufficient funds. Available: $${selectedAccount.balance.toFixed(2)}`;
      }
    }

    if (type === "new-account") {
      if (!holderName.trim() || holderName.trim().length < 2) {
        newErrors.holderName = "Full name must be at least 2 characters";
      }
      const dep = parseFloat(initialDeposit);
      if (!initialDeposit || isNaN(dep) || dep < 0) {
        newErrors.initialDeposit = "Initial deposit must be 0 or greater";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    if (type === "new-account" && step === "form") { setStep("confirm"); return; }

    if (!selectedAccount && type !== "new-account") return;

    setSuccess(true);
    setTimeout(() => {
      if (type === "deposit") deposit(selectedAccount!.id, parseFloat(amount), note || undefined);
      else if (type === "withdraw") withdraw(selectedAccount!.id, parseFloat(amount), note || undefined);
      else if (type === "transfer") transfer(selectedAccount!.id, toAccountId, parseFloat(amount), note || undefined);
      else if (type === "new-account") createAccount(holderName, accountType, parseFloat(initialDeposit) || 0);

      setTimeout(() => { setSuccess(false); handleClose(); }, 800);
    }, 300);
  };

  const config: Record<DrawerProps["type"], { title: string; color: string }> = {
    deposit: { title: "Deposit Funds", color: "#00C9A7" },
    withdraw: { title: "Withdraw Funds", color: "#FF5C5C" },
    transfer: { title: "Transfer Funds", color: "#6495ED" },
    "new-account": { title: "New Account", color: "#A78BFA" },
  };

  const otherAccounts = accounts.filter((a) => a.id !== selectedAccount?.id);

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 z-40 transition-all duration-300"
        style={{
          background: isOpen ? "rgba(0,0,0,0.6)" : "transparent",
          backdropFilter: isOpen ? "blur(4px)" : "none",
          pointerEvents: isOpen ? "auto" : "none",
        }}
        onClick={handleClose}
      />

      {/* Drawer */}
      <div
        className="fixed bottom-0 left-0 right-0 z-50 rounded-t-3xl transition-transform duration-300 ease-out"
        style={{
          background: "#1C2E42",
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.6)",
          transform: isOpen ? "translateY(0)" : "translateY(100%)",
          maxHeight: "90vh",
          overflow: "hidden",
        }}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full" style={{ background: "rgba(255,255,255,0.15)" }} />
        </div>

        <div className="px-6 pb-8 overflow-y-auto max-h-[80vh]">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: `${config[type].color}15`, border: `1px solid ${config[type].color}30` }}
              >
                <DollarSign size={18} style={{ color: config[type].color }} />
              </div>
              <div>
                <h3
                  className="text-[#E8F0F7] font-bold text-lg"
                  style={{ fontFamily: "Syne, sans-serif" }}
                >
                  {config[type].title}
                </h3>
                {selectedAccount && type !== "new-account" && (
                  <p className="text-[#7A9BB5] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>
                    {selectedAccount.holderName} • {selectedAccount.accountType}
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={handleClose}
              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
              style={{ border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <X size={14} className="text-[#7A9BB5]" />
            </button>
          </div>

          {/* Success state */}
          {success && (
            <div
              className="flex flex-col items-center justify-center py-8 gap-3"
            >
              <div
                className="w-16 h-16 rounded-full flex items-center justify-center"
                style={{ background: "rgba(0,201,167,0.15)", border: "2px solid rgba(0,201,167,0.4)" }}
              >
                <CheckCircle size={28} className="text-[#00C9A7]" />
              </div>
              <p className="text-[#E8F0F7] font-semibold" style={{ fontFamily: "Manrope, sans-serif" }}>
                Transaction Successful
              </p>
            </div>
          )}

          {/* Form */}
          {!success && (
            <>
              {step === "confirm" && type === "new-account" ? (
                <div className="space-y-4">
                  <div
                    className="rounded-xl p-4 space-y-3"
                    style={{ background: "rgba(167,139,250,0.06)", border: "1px solid rgba(167,139,250,0.15)" }}
                  >
                    <p className="text-[#7A9BB5] text-xs uppercase tracking-widest mb-2" style={{ fontFamily: "Manrope, sans-serif" }}>
                      Confirm Account Details
                    </p>
                    {[
                      { label: "Name", value: holderName },
                      { label: "Type", value: accountType },
                      { label: "Initial Deposit", value: `$${parseFloat(initialDeposit || "0").toFixed(2)}` },
                    ].map((item) => (
                      <div key={item.label} className="flex justify-between">
                        <span className="text-[#7A9BB5] text-sm" style={{ fontFamily: "Manrope, sans-serif" }}>{item.label}</span>
                        <span className="text-[#E8F0F7] text-sm font-medium" style={{ fontFamily: "Manrope, sans-serif" }}>{item.value}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={() => setStep("form")}
                      className="flex-1 py-3 rounded-xl text-sm font-medium transition-all hover:bg-white/5"
                      style={{
                        border: "1px solid rgba(255,255,255,0.1)",
                        color: "#7A9BB5",
                        fontFamily: "Manrope, sans-serif",
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={handleSubmit}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90"
                      style={{
                        background: "linear-gradient(135deg, #A78BFA, #7C3AED)",
                        color: "white",
                        fontFamily: "Manrope, sans-serif",
                      }}
                    >
                      Confirm & Create
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* New Account fields */}
                  {type === "new-account" && (
                    <>
                      <div>
                        <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                          Full Name *
                        </label>
                        <input
                          type="text"
                          placeholder="Enter full name"
                          value={holderName}
                          onChange={(e) => { setHolderName(e.target.value); setErrors((p) => ({ ...p, holderName: "" })); }}
                          className="w-full px-4 py-3 rounded-xl text-sm text-[#E8F0F7] placeholder-[#7A9BB5] outline-none focus:ring-1 focus:ring-[#A78BFA]/50 transition-all"
                          style={{
                            background: "rgba(255,255,255,0.04)",
                            border: `1px solid ${errors.holderName ? "#FF5C5C" : "rgba(255,255,255,0.1)"}`,
                            fontFamily: "Manrope, sans-serif",
                          }}
                        />
                        {errors.holderName && (
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <AlertCircle size={11} className="text-[#FF5C5C]" />
                            <p className="text-[#FF5C5C] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>{errors.holderName}</p>
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                          Account Type
                        </label>
                        <div className="grid grid-cols-2 gap-2">
                          {(["Savings", "Checking"] as const).map((t) => (
                            <button
                              key={t}
                              onClick={() => setAccountType(t)}
                              className="py-3 rounded-xl text-sm font-medium transition-all"
                              style={{
                                background: accountType === t ? "rgba(167,139,250,0.15)" : "rgba(255,255,255,0.04)",
                                border: `1px solid ${accountType === t ? "rgba(167,139,250,0.4)" : "rgba(255,255,255,0.08)"}`,
                                color: accountType === t ? "#A78BFA" : "#7A9BB5",
                                fontFamily: "Manrope, sans-serif",
                              }}
                            >
                              {t}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                          Initial Deposit ($)
                        </label>
                        <div className="relative">
                          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7A9BB5] text-sm" style={{ fontFamily: "JetBrains Mono, monospace" }}>$</span>
                          <input
                            type="number"
                            min="0"
                            placeholder="0.00"
                            value={initialDeposit}
                            onChange={(e) => { setInitialDeposit(e.target.value); setErrors((p) => ({ ...p, initialDeposit: "" })); }}
                            className="w-full pl-8 pr-4 py-3 rounded-xl text-sm text-[#E8F0F7] placeholder-[#7A9BB5] outline-none focus:ring-1 transition-all"
                            style={{
                              background: "rgba(255,255,255,0.04)",
                              border: `1px solid ${errors.initialDeposit ? "#FF5C5C" : "rgba(255,255,255,0.1)"}`,
                              fontFamily: "JetBrains Mono, monospace",
                            }}
                          />
                        </div>
                        {errors.initialDeposit && (
                          <div className="flex items-center gap-1.5 mt-1.5">
                            <AlertCircle size={11} className="text-[#FF5C5C]" />
                            <p className="text-[#FF5C5C] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>{errors.initialDeposit}</p>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {/* Transfer destination */}
                  {type === "transfer" && (
                    <div>
                      <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                        Destination Account *
                      </label>
                      <select
                        value={toAccountId}
                        onChange={(e) => { setToAccountId(e.target.value); setErrors((p) => ({ ...p, toAccount: "" })); }}
                        className="w-full px-4 py-3 rounded-xl text-sm text-[#E8F0F7] outline-none focus:ring-1 focus:ring-[#6495ED]/50 transition-all"
                        style={{
                          background: "rgba(255,255,255,0.04)",
                          border: `1px solid ${errors.toAccount ? "#FF5C5C" : "rgba(255,255,255,0.1)"}`,
                          fontFamily: "Manrope, sans-serif",
                        }}
                      >
                        <option value="" style={{ background: "#1C2E42" }}>Select account...</option>
                        {otherAccounts.map((a) => (
                          <option key={a.id} value={a.id} style={{ background: "#1C2E42" }}>
                            {a.holderName} — •••{a.accountNumber.slice(-4)}
                          </option>
                        ))}
                      </select>
                      {errors.toAccount && (
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <AlertCircle size={11} className="text-[#FF5C5C]" />
                          <p className="text-[#FF5C5C] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>{errors.toAccount}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Amount */}
                  {type !== "new-account" && (
                    <div>
                      <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                        Amount *
                      </label>
                      {type === "withdraw" && selectedAccount && (
                        <p className="text-[#7A9BB5] text-xs mb-2" style={{ fontFamily: "Manrope, sans-serif" }}>
                          Available: <span style={{ color: "#00C9A7", fontFamily: "JetBrains Mono, monospace" }}>
                            ${selectedAccount.balance.toFixed(2)}
                          </span>
                        </p>
                      )}
                      <div className="relative">
                        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#7A9BB5]" style={{ fontFamily: "JetBrains Mono, monospace" }}>$</span>
                        <input
                          type="number"
                          min="0"
                          placeholder="0.00"
                          value={amount}
                          onChange={(e) => { setAmount(e.target.value); setErrors((p) => ({ ...p, amount: "" })); }}
                          className="w-full pl-8 pr-4 py-3 rounded-xl text-sm text-[#E8F0F7] placeholder-[#7A9BB5] outline-none focus:ring-1 transition-all"
                          style={{
                            background: "rgba(255,255,255,0.04)",
                            border: `1px solid ${errors.amount ? "#FF5C5C" : "rgba(255,255,255,0.1)"}`,
                            fontFamily: "JetBrains Mono, monospace",
                          }}
                        />
                      </div>
                      {errors.amount && (
                        <div className="flex items-center gap-1.5 mt-1.5">
                          <AlertCircle size={11} className="text-[#FF5C5C]" />
                          <p className="text-[#FF5C5C] text-xs" style={{ fontFamily: "Manrope, sans-serif" }}>{errors.amount}</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Note */}
                  {type !== "new-account" && (
                    <div>
                      <label className="block text-xs text-[#7A9BB5] mb-2 uppercase tracking-wider" style={{ fontFamily: "Manrope, sans-serif" }}>
                        Note (optional)
                      </label>
                      <div className="relative">
                        <FileText size={13} className="absolute left-3 top-3 text-[#7A9BB5]" />
                        <textarea
                          placeholder="Add a note..."
                          value={note}
                          onChange={(e) => setNote(e.target.value)}
                          rows={2}
                          className="w-full pl-9 pr-4 py-3 rounded-xl text-sm text-[#E8F0F7] placeholder-[#7A9BB5] outline-none focus:ring-1 focus:ring-[#00C9A7]/40 resize-none transition-all"
                          style={{
                            background: "rgba(255,255,255,0.04)",
                            border: "1px solid rgba(255,255,255,0.1)",
                            fontFamily: "Manrope, sans-serif",
                          }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-3 pt-2">
                    <button
                      onClick={handleClose}
                      className="flex-1 py-3 rounded-xl text-sm font-medium transition-all hover:bg-white/5"
                      style={{
                        border: "1px solid rgba(255,255,255,0.1)",
                        color: "#7A9BB5",
                        fontFamily: "Manrope, sans-serif",
                      }}
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSubmit}
                      className="flex-1 py-3 rounded-xl text-sm font-semibold transition-all hover:opacity-90 active:scale-95"
                      style={{
                        background: `linear-gradient(135deg, ${config[type].color}, ${config[type].color}cc)`,
                        color: type === "deposit" || type === "new-account" ? "#0D1B2A" : "white",
                        fontFamily: "Manrope, sans-serif",
                        boxShadow: `0 4px 16px ${config[type].color}33`,
                      }}
                    >
                      {type === "new-account" ? "Review & Confirm" : "Confirm"}
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Drawer;
