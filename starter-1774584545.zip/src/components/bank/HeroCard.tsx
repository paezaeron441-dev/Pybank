import React, { useState, useEffect, useRef } from "react";
import { Wallet, CreditCard, Eye, EyeOff, TrendingUp } from "lucide-react";
import { useBank } from "@/context/BankContext";

interface HeroCardProps {
  onBalanceInquiry: () => void;
  isPulsing: boolean;
}

const HeroCard: React.FC<HeroCardProps> = ({ onBalanceInquiry, isPulsing }) => {
  const { selectedAccount } = useBank();
  const [showNumber, setShowNumber] = useState(false);
  const [displayBalance, setDisplayBalance] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const prevBalance = useRef(0);

  useEffect(() => {
    if (!selectedAccount) return;
    const target = selectedAccount.balance;
    const start = prevBalance.current;
    const diff = target - start;
    const duration = 800;
    const startTime = performance.now();

    setIsAnimating(true);
    const animate = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayBalance(start + diff * eased);
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setDisplayBalance(target);
        prevBalance.current = target;
        setIsAnimating(false);
      }
    };
    requestAnimationFrame(animate);
  }, [selectedAccount?.balance, selectedAccount?.id]);

  if (!selectedAccount) {
    return (
      <div
        className="rounded-2xl p-8 flex items-center justify-center min-h-[180px]"
        style={{ background: "#1C2E42", border: "1px solid rgba(255,255,255,0.06)" }}
      >
        <p className="text-[#7A9BB5]" style={{ fontFamily: "Manrope, sans-serif" }}>
          Select an account
        </p>
      </div>
    );
  }

  const maskNumber = (num: string) => {
    if (showNumber) return num.replace(/(\d{4})/g, "$1 ").trim();
    return `•••• •••• •••• ${num.slice(-4)}`;
  };

  const formatBalance = (val: number) =>
    new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(val);

  return (
    <div
      className="relative rounded-2xl p-7 overflow-hidden transition-all duration-300"
      style={{
        background: "linear-gradient(135deg, #1C2E42 0%, #162539 50%, #0D1E30 100%)",
        border: `1px solid ${isPulsing ? "rgba(0,201,167,0.5)" : "rgba(0,201,167,0.15)"}`,
        boxShadow: isPulsing
          ? "0 0 40px rgba(0,201,167,0.25), 0 8px 32px rgba(0,0,0,0.4)"
          : "0 8px 32px rgba(0,0,0,0.4)",
        transition: "all 0.3s ease",
      }}
      onClick={onBalanceInquiry}
    >
      {/* Radial glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse at 50% 120%, rgba(0,201,167,0.12) 0%, transparent 70%)",
        }}
      />
      {/* Noise texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20 rounded-2xl"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Pulse ring */}
      {isPulsing && (
        <div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{
            border: "2px solid rgba(0,201,167,0.6)",
            animation: "ping 0.8s ease-out",
          }}
        />
      )}

      <div className="relative z-10">
        {/* Top row */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <p
              className="text-[#7A9BB5] text-xs uppercase tracking-widest mb-1"
              style={{ fontFamily: "Manrope, sans-serif" }}
            >
              Account Holder
            </p>
            <h2
              className="text-[#E8F0F7] font-bold text-xl"
              style={{ fontFamily: "Syne, sans-serif" }}
            >
              {selectedAccount.holderName}
            </h2>
          </div>
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-full"
            style={{
              background: selectedAccount.accountType === "Savings"
                ? "rgba(0,201,167,0.1)"
                : "rgba(100,149,237,0.1)",
              border: `1px solid ${selectedAccount.accountType === "Savings" ? "rgba(0,201,167,0.25)" : "rgba(100,149,237,0.25)"}`,
            }}
          >
            {selectedAccount.accountType === "Savings" ? (
              <Wallet size={13} className="text-[#00C9A7]" />
            ) : (
              <CreditCard size={13} className="text-[#6495ED]" />
            )}
            <span
              className="text-xs font-semibold"
              style={{
                color: selectedAccount.accountType === "Savings" ? "#00C9A7" : "#6495ED",
                fontFamily: "Manrope, sans-serif",
              }}
            >
              {selectedAccount.accountType}
            </span>
          </div>
        </div>

        {/* Balance */}
        <div className="mb-5">
          <p
            className="text-[#7A9BB5] text-xs uppercase tracking-widest mb-1"
            style={{ fontFamily: "Manrope, sans-serif" }}
          >
            Current Balance
          </p>
          <div className="flex items-end gap-3">
            <span
              className="font-extrabold leading-none"
              style={{
                fontFamily: "JetBrains Mono, monospace",
                fontSize: "clamp(28px, 4vw, 42px)",
                color: "#00C9A7",
                textShadow: "0 0 30px rgba(0,201,167,0.3)",
              }}
            >
              {formatBalance(displayBalance)}
            </span>
            {isAnimating && (
              <TrendingUp size={16} className="text-[#00C9A7] mb-2 animate-bounce" />
            )}
          </div>
        </div>

        {/* Account number */}
        <div className="flex items-center justify-between">
          <div>
            <p
              className="text-[#7A9BB5] text-[10px] uppercase tracking-widest mb-1"
              style={{ fontFamily: "Manrope, sans-serif" }}
            >
              Account Number
            </p>
            <span
              className="text-[#E8F0F7] text-sm tracking-[0.15em]"
              style={{ fontFamily: "JetBrains Mono, monospace" }}
            >
              {maskNumber(selectedAccount.accountNumber)}
            </span>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); setShowNumber(!showNumber); }}
            className="w-8 h-8 rounded-full flex items-center justify-center transition-all hover:bg-white/5"
            style={{ border: "1px solid rgba(255,255,255,0.08)" }}
          >
            {showNumber ? (
              <EyeOff size={13} className="text-[#7A9BB5]" />
            ) : (
              <Eye size={13} className="text-[#7A9BB5]" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default HeroCard;
