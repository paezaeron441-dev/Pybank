export type UserRole = "admin" | "staff" | "customer";

export type AccountType = "Savings" | "Checking";

export interface Account {
  id: string;
  accountNumber: string;
  holderName: string;
  accountType: AccountType;
  balance: number;
  createdAt: string;
}

export interface Transaction {
  id: string;
  accountId: string;
  type: "deposit" | "withdrawal" | "transfer_in" | "transfer_out";
  amount: number;
  note?: string;
  runningBalance: number;
  date: string;
  toAccountId?: string;
  toAccountNumber?: string;
}

export interface Notification {
  id: string;
  message: string;
  type: "success" | "error" | "info";
  timestamp: string;
  read: boolean;
}
